package com.sergio.examen;

import com.sergio.examen.ejercicios.Programa1;

public class Main {
    public static void main(String[] args) {

        Programa1 ejercicio1 =  new Programa1();
    }
}
