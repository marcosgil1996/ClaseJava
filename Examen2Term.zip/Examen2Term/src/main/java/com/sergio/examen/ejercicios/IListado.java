package com.sergio.examen.ejercicios;

import java.util.ArrayList;

public interface IListado {

}
